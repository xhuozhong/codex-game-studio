@echo off
setlocal
cd /d "%~dp0"
echo.
echo ================================================
echo   Codex Game Studio 2.0.0 - REPAIR / REINSTALL
echo   Offline / Self-Contained
echo ================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1" -Scope User -Force
set EXITCODE=%ERRORLEVEL%
echo.
if "%EXITCODE%"=="0" (
  echo [OK] Repair/reinstall completed.
  echo Fully close and reopen Codex, then run /skills.
  echo Then use: $game-studio-director
) else (
  echo [FAILED] Repair failed with exit code %EXITCODE%.
  echo Please copy the complete error message and send it to ChatGPT.
)
echo.
pause
exit /b %EXITCODE%
