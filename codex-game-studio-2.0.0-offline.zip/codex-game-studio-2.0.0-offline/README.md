# Codex Game Studio 2.0.0 — Offline Self-Contained Skill Team

这是一个**无需联网下载第三方 Skill** 的 Codex 游戏开发团队安装包。

## 团队结构

- `game-studio-director` — 总导演 / 制作人 / 技术总监（调度入口）
- `higgsfield-game-generation` — 游戏生成与资产生产
- `game-engine` — 游戏引擎与运行时架构
- `multiplayer-game` — 多人联机与实时状态
- `game-developer` — 通用游戏程序开发
- `game-ui-design` — UI视觉设计
- `game-design-theory` — 游戏策划与可玩性
- `game-feel` — 游戏手感与反馈
- `game-ui-ux` — UI/UX、响应式与输入可达性
- `threejs-game-ui-designer` — Three.js 3D网页游戏UI
- `develop-web-game` — 网页游戏自动试玩、截图、检查、回归

> 这是本地自包含兼容版。它不在安装阶段访问 GitHub/codeload，也不需要 Git、GitHub CLI 或网络权限。

## Windows 安装

### 最简单

双击：

`INSTALL_WINDOWS.cmd`

### PowerShell

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1
```

默认安装到：

`%USERPROFILE%\.agents\skills`

项目级安装：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -Scope Project -ProjectRoot "D:\Games\MyGame"
```

如果之前安装过旧版：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -Force
```

安装器会把同名旧目录备份为 `.backup-YYYYMMDD-HHMMSS`，不会直接删除。

## 安装后

完全退出并重新打开 Codex，然后：

```text
/skills
```

应看到 `game-studio-director` 与 10 个专家。

### 总导演调用

```text
$game-studio-director

接管当前游戏项目。读取项目文档、源码和测试配置，识别当前阶段。
为我完成下一项最重要的玩家可见功能。
你负责选择专家，不要让我手动编排。
一个功能只允许 1 个主负责人，最多 3 个辅助专家。
网页游戏每次重要改动后必须实际运行、自动试玩、截图/状态检查、Console 检查并回归测试。
不要只给方案，直接实现并验证。
```

## 为什么这个版本不会重复失败

1. 安装包内已经包含全部 11 个 Skill；
2. 安装阶段不执行 `Invoke-WebRequest`、`git clone` 或 GitHub API 下载；
3. 不依赖 `codeload.github.com`；
4. 不要求 GitHub 登录；
5. 不要求 GitHub CLI；
6. 只需要把本地 Skill 目录复制到 Codex 的 `.agents/skills`；
7. 安装前会检查每个 `SKILL.md` 的 YAML frontmatter 和目录名；
8. 同名目录默认停止，`-Force` 才会备份后覆盖。

## 卸载

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\uninstall.ps1
```

## 重要说明

本包的目标是让“游戏开发团队”作为一个可移植的 Codex Skill Team 工作。它不是把第三方仓库原封不动打包，而是提供一套本地、独立、可调度的角色 Skill；需要特定第三方工具时，Skill 会明确要求检查工具是否存在，不会假装工具已经安装。
