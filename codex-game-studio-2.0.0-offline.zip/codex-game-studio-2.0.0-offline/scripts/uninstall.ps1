[CmdletBinding()]
param([ValidateSet('User','Project')][string]$Scope='User',[string]$ProjectRoot=(Get-Location).Path,[string]$TargetPath='')
$ErrorActionPreference='Stop'
if ($TargetPath) {$root=[System.IO.Path]::GetFullPath($TargetPath)} elseif ($Scope -eq 'Project') {$root=Join-Path ([System.IO.Path]::GetFullPath($ProjectRoot)) '.agents\skills'} else {$root=Join-Path $HOME '.agents\skills'}
$names=@('game-studio-director','higgsfield-game-generation','game-engine','multiplayer-game','game-developer','game-ui-design','game-design-theory','game-feel','game-ui-ux','threejs-game-ui-designer','develop-web-game')
foreach($name in $names){$p=Join-Path $root $name;if(Test-Path -LiteralPath $p){Remove-Item -LiteralPath $p -Recurse -Force;Write-Host "Removed $name" -ForegroundColor Yellow}}
Write-Host "Done: $root" -ForegroundColor Green
