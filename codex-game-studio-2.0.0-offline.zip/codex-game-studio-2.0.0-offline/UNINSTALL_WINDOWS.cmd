@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\uninstall.ps1" -Scope User
set EXITCODE=%ERRORLEVEL%
echo.
if "%EXITCODE%"=="0" echo [OK] Codex Game Studio uninstalled.
if not "%EXITCODE%"=="0" echo [FAILED] Uninstall failed with exit code %EXITCODE%.
pause
exit /b %EXITCODE%
