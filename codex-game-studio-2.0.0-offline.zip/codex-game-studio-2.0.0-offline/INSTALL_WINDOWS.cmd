@echo off
setlocal
cd /d "%~dp0"
echo.
echo ================================================
echo      Codex Game Studio 2.0.0 Installer
echo      Offline / Self-Contained
echo ================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1" -Scope User
set EXITCODE=%ERRORLEVEL%
echo.
if not "%EXITCODE%"=="0" (
  echo [FAILED] Installation failed with exit code %EXITCODE%.
  echo If you already installed an older version, run REPAIR_WINDOWS.cmd instead.
) else (
  echo [OK] Codex Game Studio installed.
  echo Fully restart Codex, then run /skills.
  echo Then call: $game-studio-director
)
echo.
pause
exit /b %EXITCODE%
