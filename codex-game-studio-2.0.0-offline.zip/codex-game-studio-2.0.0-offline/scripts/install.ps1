[CmdletBinding()]
param(
  [ValidateSet('User','Project')][string]$Scope = 'User',
  [string]$ProjectRoot = (Get-Location).Path,
  [string]$TargetPath = '',
  [switch]$Force
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$PackageRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$SourceRoot = Join-Path $PackageRoot 'skills'
if ($TargetPath) { $InstallRoot = [System.IO.Path]::GetFullPath($TargetPath) }
elseif ($Scope -eq 'Project') { $InstallRoot = Join-Path ([System.IO.Path]::GetFullPath($ProjectRoot)) '.agents\skills' }
else { $InstallRoot = Join-Path $HOME '.agents\skills' }
Write-Host 'Codex Game Studio 2.0.0 - OFFLINE installer' -ForegroundColor Cyan
Write-Host "Target: $InstallRoot"
if (-not (Test-Path -LiteralPath $SourceRoot -PathType Container)) { throw "Missing package skills directory: $SourceRoot" }
$skills = @(Get-ChildItem -LiteralPath $SourceRoot -Directory | Sort-Object Name)
if ($skills.Count -ne 11) { throw "Package integrity error: expected 11 skills, found $($skills.Count)." }
foreach ($skill in $skills) {
  $f = Join-Path $skill.FullName 'SKILL.md'
  if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { throw "Missing SKILL.md: $f" }
  $t = Get-Content -LiteralPath $f -Raw -Encoding UTF8
  if ($t -notmatch '(?s)^---\r?\n') { throw "Invalid frontmatter: $f" }
  $m = [regex]::Match($t, '(?m)^name:\s*([a-z0-9-]+)\s*$')
  if (-not $m.Success) { throw "Missing/invalid name in: $f" }
  if ($m.Groups[1].Value -ne $skill.Name) { throw "Skill name '$($m.Groups[1].Value)' != directory '$($skill.Name)'" }
  if ($t -notmatch '(?m)^description:\s*.+$') { throw "Missing description in: $f" }
}
New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
foreach ($skill in $skills) {
  $dest = Join-Path $InstallRoot $skill.Name
  if (Test-Path -LiteralPath $dest) {
    if (-not $Force) { throw "Skill already exists: $dest`nRun again with -Force to back it up and replace it." }
    $backup = "$dest.backup-$timestamp"
    Move-Item -LiteralPath $dest -Destination $backup
    Write-Host "Backed up: $($skill.Name)" -ForegroundColor Yellow
  }
  Copy-Item -LiteralPath $skill.FullName -Destination $dest -Recurse -Force
  Write-Host "Installed: $($skill.Name)" -ForegroundColor Green
}
Write-Host ''
Write-Host "SUCCESS. Installed 11 skills to $InstallRoot" -ForegroundColor Green
Write-Host 'Fully restart Codex, run /skills, then use $game-studio-director.' -ForegroundColor White
